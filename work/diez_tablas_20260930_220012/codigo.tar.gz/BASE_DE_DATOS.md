# Tablas físicas del portal

La migración `0009_consolidar_tablas` reduce el esquema de 16 a 14 tablas. No crea vistas SQL, vistas materializadas, tablas temporales ni modelos proxy.

## Consolidación

- `compromisos_eventocompromiso`: conserva las entradas de auditoría y las reprogramaciones, distinguidas por `tipo`. Mantiene autores, fechas, motivos, número de reprogramación y el ID original en `origen_id`. `compromiso.historial` y `compromiso.reprogramaciones` son consultas ORM filtradas sobre esta tabla física, no vistas de PostgreSQL.
- `compromisos_envionotificacion`: conserva envíos de correo y Teams, distinguidos por `canal`. La restricción única `(canal, token)` conserva la protección frente a duplicados, incluso si ambos canales usan un mismo UUID.
- `compromisos` y `compromisos_estado`: permanecen para datos del portal y administración de etiquetas/estados.

Las otras 10 tablas pertenecen a Django: usuarios, grupos, permisos, relaciones de acceso, sesiones, auditoría administrativa, tipos de contenido y migraciones. Se conservan para mantener el inicio de sesión, cierre/revocación de sesiones, roles, gestión de usuarios y administración técnica. Eliminarlas exige sustituir esos subsistemas; mover los datos a un archivo no equivaldría a conservar el funcionamiento actual en PostgreSQL.

## Aplicación y reversión

Detener los procesos del portal antes de modificar el esquema. Mantener un respaldo PostgreSQL completo y una copia del código anterior.

```sh
./.venv/bin/python manage.py migrate
./.venv/bin/python manage.py check
```

La migración copia registros y valida los totales antes de retirar las tablas anteriores, dentro de una transacción en PostgreSQL. Los permisos anteriores se conservan y se añaden sus equivalentes para los modelos consolidados. Los tipos de contenido antiguos no se borran para conservar referencias de auditoría.

Para revertir, con el portal detenido y después de otro respaldo:

```sh
./.venv/bin/python manage.py migrate compromisos 0008
```

La reversión reconstruye las cuatro tablas originales, restaura sus IDs y fechas y copia también los eventos creados tras consolidar. Restaurar luego el código anterior antes de iniciar el portal. No ejecutar `init_portal` para migrar datos: ese comando inicializa roles y estados y no es necesario para esta consolidación.
